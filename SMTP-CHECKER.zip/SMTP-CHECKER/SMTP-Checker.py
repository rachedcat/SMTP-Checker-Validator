import smtplib
import time
import os
from imp import reload
from colorama import init, Fore, Style
import sys
import os
init(convert=True)
os.system("cls")
init(autoreset=True)
reload(sys)
r = Fore.RED + Style.BRIGHT
g = Fore.GREEN + Style.BRIGHT
c = Fore.CYAN + Style.BRIGHT
y = Fore.YELLOW + Style.BRIGHT
o = Fore.RESET + Style.RESET_ALL
banner = """

               {}[!] {}PHONE-NUMBER-GENERATOR {} - {}^-^{}
                    {}^-^STUPID-CAT^-^{}
	                {}CONTACT ME:{}
              {}https://t.me/stupidcat07
              https://www.linkedin.com/in/rached-mhamdi/{}
	      {}Donate for me : 
            TRC20-  TEt1axXs9TyXcHjhvYHocSsTqjQ5jKivbz
	        BTC -  19h2h2aWFdv4JsLoTZkrL8qf212BiiBUwf
            # DISCLAIMER: This software is provided for educational and informational purposes only. 
            # The author and contributors are not responsible for any illegal or unethical use of this software.{}


""".format(r, g, y, g, o, r, o, y, o, r, o, g, o)

def connect_to_smtp(smtp_info):
    host, port, username, password = smtp_info.split("|")
    try:
        smtp_conn = smtplib.SMTP(host, port)
        smtp_conn.ehlo()
        smtp_conn.login(username, password)
        return smtp_conn, smtp_info
    except:
        return None, None

def send_email(smtp_conn, sender_email, recipient_email, subject, message):
    headers = "\r\n".join(["from: " + sender_email,
                           "subject: " + subject,
                           "to: " + recipient_email,
                           "mime-version: 1.0",
                           "content-type: text/html"])
    content = headers + "\r\n\r\n" + message
    try:
        smtp_conn.sendmail(sender_email, recipient_email, content)
        return True
    except:
        return False

#MAIN 
print(banner)

# Read in the list of SMTP servers from a file
with open("smtps.txt", "r") as f:
    smtp_list = f.read().splitlines()

# Set up the recipient email address
recipient_email = str(input("Your email: "))

# Set up the email subject and message
subject = "SMTP Server Test"
message = "Hello, this is a test email from Python!"

# Set up list to store working SMTPs
working_smtps = []

# Iterate through the SMTP servers and send the email if the server is available
for smtp_info in smtp_list:
    smtp_info_parts = smtp_info.split("|")
    if len(smtp_info_parts) != 4:
        print("Skipping invalid SMTP format: ", smtp_info)
        continue
    
    host, port, username, password = smtp_info_parts
    print("Trying to connect to", host, "on port", port)
    
    smtp_conn, smtp_info = connect_to_smtp(smtp_info)
    if smtp_conn and smtp_info:
        if send_email(smtp_conn, username, recipient_email, subject, message):
            print("Email sent successfully using SMTP server:", smtp_info)
            working_smtps.append(smtp_info)
            # Write the working SMTPs to a file
            with open("Working_smtps.txt", "a") as f:
                f.write("\n".join(working_smtps))
        else:
            print("Error sending email using SMTP server:", smtp_info)
        smtp_conn.quit()
    else:
        print("Error connecting to SMTP server:", smtp_info)
    time.sleep(5)
h=input("rached taa zeby kmlt !")
